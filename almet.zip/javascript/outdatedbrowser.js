

//DOM ready or jQuery
    outdatedBrowser({
        bgColor: 'rgba(0, 0, 0, 0.9)',
        color: '#ffffff',
        lowerThan: 'transform',
        languagePath: 'bower_components/outdated-browser/outdatedbrowser/lang/ru.html'
    })
