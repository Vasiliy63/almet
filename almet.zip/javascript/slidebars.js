(function($) {
      $(document).ready(function() {
        $.slidebars({
          scrollLock: true
        });
      });
    }) (jQuery);
